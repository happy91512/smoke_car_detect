import numpy as np


class Tracker:
    # tid = 0

    def __init__(self, key: str, bboxs: np.ndarray) -> None:
        tid, cls, fframe = key.split('_')[1:]

        self.tid: int = int(tid.split('_')[-1])
        self.cls: int = cls
        self.fframe: int = int(fframe[1:])
        self.lframe: int = self.fframe + bboxs.shape[0]
        self.bboxs: np.ndarray = bboxs

    def __repr__(self) -> str:
        return f'OT-{self.tid}'
